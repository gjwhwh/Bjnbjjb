package ir.beny.bot.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("beny_bot", Context.MODE_PRIVATE)
    private val secure = EncryptedSharedPreferences.create(
        ctx, "beny_keys",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var providerId: String
        get() = p.getString("provider", "openai")!!
        set(v) = p.edit().putString("provider", v).apply()
    var temperature: Float
        get() = p.getFloat("temp", 0.7f)
        set(v) = p.edit().putFloat("temp", v).apply()
    var systemPrompt: String
        get() = p.getString("system", DEFAULT_SYSTEM)!!
        set(v) = p.edit().putString("system", v).apply()

    fun key(id: String) = secure.getString("key_$id", "")!!
    fun setKey(id: String, v: String) = secure.edit().putString("key_$id", v.trim()).apply()
    fun model(id: String) = p.getString("model_$id", Providers.byId(id).models.firstOrNull() ?: "")!!
    fun setModel(id: String, v: String) = p.edit().putString("model_$id", v.trim()).apply()
    fun base(id: String) = p.getString("base_$id", Providers.byId(id).baseUrl)!!
    fun setBase(id: String, v: String) = p.edit().putString("base_$id", v.trim()).apply()

    fun loadChats(): List<Chat> = runCatching {
        val arr = JSONArray(p.getString("chats", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val c = Chat(o.getString("id"), o.getString("title"))
            val m = o.getJSONArray("messages")
            for (i in 0 until m.length()) {
                val mo = m.getJSONObject(i)
                c.messages.add(Msg(mo.getString("role"), mo.getString("content")))
            }
            c
        }
    }.getOrDefault(emptyList())

    fun saveChats(chats: List<Chat>) {
        val arr = JSONArray()
        chats.forEach { c ->
            arr.put(JSONObject().put("id", c.id).put("title", c.title).put("messages", JSONArray().also { m ->
                c.messages.forEach { m.put(JSONObject().put("role", it.role).put("content", it.content)) }
            }))
        }
        p.edit().putString("chats", arr.toString()).apply()
    }

    companion object {
        const val DEFAULT_SYSTEM = "تو «بنی‌بات» هستی، یک دستیار هوشمند و مفید. به زبانی که کاربر می‌نویسد پاسخ بده."
    }
}
