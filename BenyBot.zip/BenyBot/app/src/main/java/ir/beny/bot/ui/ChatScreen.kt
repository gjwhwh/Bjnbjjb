package ir.beny.bot.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.beny.bot.data.Msg
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val listState = rememberLazyListState()
    val chat = vm.current
    var input by remember { mutableStateOf("") }
    val count = chat?.messages?.size ?: 0

    LaunchedEffect(count, vm.loading, vm.currentId) {
        if (count > 0) listState.animateScrollToItem(count + if (vm.loading) 0 else -1)
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text("تاریخچه", Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge)
                FilledTonalButton(
                    onClick = { vm.newChat(); scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("گفتگوی جدید") }
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.chats.toList(), key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = { Text(c.title, maxLines = 1) },
                            selected = c.id == vm.currentId,
                            onClick = { vm.open(c.id); scope.launch { drawer.close() } },
                            badge = { IconButton(onClick = { vm.delete(c.id) }) { Icon(Icons.Default.Delete, "حذف") } },
                            modifier = Modifier.padding(horizontal = 8.dp),
                        )
                    }
                }
                if (vm.chats.isNotEmpty())
                    TextButton(onClick = { vm.clearAll() }, modifier = Modifier.padding(8.dp)) { Text("پاک کردن همه") }
            }
        },
    ) {
        Scaffold(
            modifier = Modifier.imePadding(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("بنی‌بات")
                            Text("${vm.provider.name} · ${vm.modelName}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "منو") } },
                    actions = {
                        if (count > 0) IconButton(onClick = {
                            ctx.startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, vm.exportText()), null))
                        }) { Icon(Icons.Default.Share, "اشتراک") }
                        IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "جدید") }
                        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "تنظیمات") }
                    },
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (count == 0) {
                        Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("سلام! من بنی‌بات هستم 👋", style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(8.dp))
                            Text("از تنظیمات کلید API سرویس دلخواهت را وارد کن و شروع کن.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    LazyColumn(state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(chat?.messages?.toList().orEmpty()) { m -> Bubble(m) }
                        if (vm.loading) item { Row(Modifier.padding(8.dp)) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text("در حال نوشتن…") } }
                        vm.error?.let { e -> item {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(e, color = MaterialTheme.colorScheme.onErrorContainer)
                                    vm.errorDetail?.let { d ->
                                        Spacer(Modifier.height(8.dp))
                                        SelectionContainer {
                                            Text(d, fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer,
                                                style = TextStyle(textDirection = TextDirection.Ltr))
                                        }
                                    }
                                }
                            }
                        } }
                    }
                }
                if (!vm.loading && count > 0)
                    TextButton(onClick = { vm.regenerate() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(4.dp)); Text("تولید مجدد")
                    }
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), placeholder = { Text("پیام…") },
                        maxLines = 5, shape = RoundedCornerShape(24.dp),
                        textStyle = TextStyle(textDirection = TextDirection.Content),
                    )
                    Spacer(Modifier.width(8.dp))
                    if (vm.loading) FilledIconButton(onClick = { vm.stop() }) { Icon(Icons.Default.Close, "توقف") }
                    else FilledIconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) {
                        Icon(Icons.AutoMirrored.Filled.Send, "ارسال")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(m: Msg) {
    val isUser = m.role == "user"
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    Box(Modifier.fillMaxWidth(), contentAlignment = if (isUser) Alignment.CenterStart else Alignment.CenterEnd) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp).combinedClickable(onClick = {}, onLongClick = {
                clip.setText(AnnotatedString(m.content))
                android.widget.Toast.makeText(ctx, "کپی شد", android.widget.Toast.LENGTH_SHORT).show()
            }),
        ) {
            SelectionContainer {
                Text(m.content, Modifier.padding(12.dp), style = TextStyle(textDirection = TextDirection.Content))
            }
        }
    }
}
