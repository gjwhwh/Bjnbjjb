package ir.beny.bot.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import ir.beny.bot.data.Providers

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val s = vm.store
    val pid = vm.providerId
    var key by remember(pid) { mutableStateOf(s.key(pid)) }
    var model by remember(pid) { mutableStateOf(s.model(pid)) }
    var base by remember(pid) { mutableStateOf(s.base(pid)) }
    var temp by remember { mutableFloatStateOf(s.temperature) }
    var system by remember { mutableStateOf(s.systemPrompt) }

    fun save() {
        s.setKey(pid, key); s.setModel(pid, model); s.setBase(pid, base)
        s.temperature = temp; s.systemPrompt = system
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("تنظیمات") },
            navigationIcon = { IconButton(onClick = { save(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("سرویس هوش مصنوعی", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Providers.all.forEach { p ->
                    FilterChip(selected = p.id == pid, onClick = { save(); vm.selectProvider(p.id) }, label = { Text(p.name) })
                }
            }
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("نام مدل") }, singleLine = true)
            val suggestions = Providers.byId(pid).models
            if (suggestions.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                suggestions.forEach { m -> AssistChip(onClick = { model = m }, label = { Text(m) }) }
            }
            OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("آدرس پایه (Base URL)") }, singleLine = true)
            Text("خلاقیت (Temperature): ${"%.1f".format(temp)}")
            Slider(temp, { temp = it }, valueRange = 0f..1.5f)
            OutlinedTextField(system, { system = it }, Modifier.fillMaxWidth(), label = { Text("پرامپت سیستم (شخصیت بات)") }, minLines = 3)
            Button(onClick = { save(); onBack() }, Modifier.fillMaxWidth()) { Text("ذخیره") }
            Text("کلیدها به‌صورت رمزنگاری‌شده روی همین دستگاه ذخیره می‌شوند.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
