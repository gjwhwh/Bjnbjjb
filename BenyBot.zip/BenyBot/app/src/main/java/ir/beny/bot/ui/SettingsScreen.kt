package ir.beny.bot.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import ir.beny.bot.data.ApiClient
import ir.beny.bot.data.ApiException
import ir.beny.bot.data.Cfg
import ir.beny.bot.data.Providers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val s = vm.store
    val pid = vm.providerId
    val prov = Providers.byId(pid)
    val scope = rememberCoroutineScope()
    var key by remember(pid) { mutableStateOf(s.key(pid)) }
    var model by remember(pid) { mutableStateOf(s.model(pid)) }
    var base by remember(pid) { mutableStateOf(s.base(pid)) }
    var temp by remember { mutableFloatStateOf(s.temperature) }
    var system by remember { mutableStateOf(s.systemPrompt) }
    var fetched by remember(pid) { mutableStateOf<List<String>>(emptyList()) }
    var fetching by remember(pid) { mutableStateOf(false) }
    var fetchError by remember(pid) { mutableStateOf<String?>(null) }

    fun save() {
        s.setKey(pid, key); s.setModel(pid, model); s.setBase(pid, base)
        s.temperature = temp; s.systemPrompt = system
    }

    fun fetchModels() {
        scope.launch {
            fetching = true; fetchError = null
            try {
                fetched = ApiClient.listModels(Cfg(prov.type, base, key, model, 0.7, "", prov.needsKey))
                if (fetched.isEmpty()) fetchError = "لیستی پیدا نشد."
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                fetchError = e.friendly
            } catch (e: IllegalArgumentException) {
                fetchError = e.message
            } catch (e: Exception) {
                fetchError = "دریافت لیست ممکن نشد. شاید این سرویس لیست مدل‌ها را نمی‌دهد؛ نام مدل را دستی بنویس."
            } finally {
                fetching = false
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("تنظیمات") },
            navigationIcon = { IconButton(onClick = { save(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("سرویس هوش مصنوعی", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Providers.all.forEach { p ->
                    FilterChip(selected = p.id == pid, onClick = { save(); vm.selectProvider(p.id) }, label = { Text(p.name) })
                }
            }
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(),
                label = { Text(if (prov.needsKey) "API Key" else "API Key (اختیاری)") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("آدرس پایه (Base URL)") }, singleLine = true)
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("نام مدل") }, singleLine = true)
            FilledTonalButton(onClick = { fetchModels() }, enabled = !fetching, modifier = Modifier.fillMaxWidth()) {
                if (fetching) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("دریافت لیست مدل‌ها از سرویس")
            }
            fetchError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            val shown = (if (fetched.isNotEmpty()) fetched.filter { model.isBlank() || it.contains(model, ignoreCase = true) } else prov.models).take(40)
            if (shown.isNotEmpty()) {
                if (fetched.isNotEmpty()) Text("${fetched.size} مدل پیدا شد. برای فیلتر، بخشی از اسم را در کادر بالا بنویس:", style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shown.forEach { m -> AssistChip(onClick = { model = m }, label = { Text(m) }) }
                }
            }
            Text("خلاقیت (Temperature): ${"%.1f".format(temp)}")
            Slider(temp, { temp = it }, valueRange = 0f..1.5f)
            OutlinedTextField(system, { system = it }, Modifier.fillMaxWidth(), label = { Text("پرامپت سیستم (شخصیت بات)") }, minLines = 3)
            Button(onClick = { save(); onBack() }, Modifier.fillMaxWidth()) { Text("ذخیره") }
            Text("کلیدها به‌صورت رمزنگاری‌شده روی همین دستگاه ذخیره می‌شوند.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
