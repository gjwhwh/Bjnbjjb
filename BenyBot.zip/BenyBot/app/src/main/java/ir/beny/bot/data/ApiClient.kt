package ir.beny.bot.data

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class Cfg(
    val type: ProviderType,
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    val temperature: Double,
    val system: String,
)

object ApiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    suspend fun send(cfg: Cfg, history: List<Msg>): String {
        require(cfg.apiKey.isNotBlank()) { "کلید API را در تنظیمات وارد کنید" }
        require(cfg.baseUrl.isNotBlank()) { "آدرس سرویس را در تنظیمات وارد کنید" }
        require(cfg.model.isNotBlank()) { "نام مدل را در تنظیمات وارد کنید" }
        val base = cfg.baseUrl.trimEnd('/')
        val req = when (cfg.type) {
            ProviderType.OPENAI_COMPAT -> openAi(cfg, base, history)
            ProviderType.ANTHROPIC -> anthropic(cfg, base, history)
            ProviderType.GEMINI -> gemini(cfg, base, history)
        }
        val (code, body) = http.newCall(req).await()
        if (code !in 200..299) throw IOException("خطا $code: ${body.take(300)}")
        return parse(cfg.type, body)
    }

    private fun post(url: String, json: JSONObject, vararg headers: Pair<String, String>): Request =
        Request.Builder().url(url).post(json.toString().toRequestBody(JSON)).apply {
            headers.forEach { (k, v) -> addHeader(k, v) }
        }.build()

    private fun openAi(c: Cfg, base: String, h: List<Msg>): Request {
        val msgs = JSONArray()
        if (c.system.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", c.system))
        h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("messages", msgs).put("temperature", c.temperature)
        return post("$base/chat/completions", body, "Authorization" to "Bearer ${c.apiKey}")
    }

    private fun anthropic(c: Cfg, base: String, h: List<Msg>): Request {
        val msgs = JSONArray()
        h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("max_tokens", 4096)
            .put("temperature", c.temperature.coerceAtMost(1.0)).put("messages", msgs)
        if (c.system.isNotBlank()) body.put("system", c.system)
        return post("$base/messages", body, "x-api-key" to c.apiKey, "anthropic-version" to "2023-06-01")
    }

    private fun gemini(c: Cfg, base: String, h: List<Msg>): Request {
        val contents = JSONArray()
        h.forEach {
            contents.put(
                JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.content)))
            )
        }
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", c.temperature))
        if (c.system.isNotBlank())
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", c.system))))
        return post("$base/models/${c.model}:generateContent", body, "x-goog-api-key" to c.apiKey)
    }

    private fun parse(type: ProviderType, body: String): String {
        val j = JSONObject(body)
        return when (type) {
            ProviderType.OPENAI_COMPAT ->
                j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
            ProviderType.ANTHROPIC -> {
                val a = j.getJSONArray("content")
                (0 until a.length()).map { a.getJSONObject(it) }
                    .filter { it.optString("type") == "text" }.joinToString("") { it.optString("text") }
            }
            ProviderType.GEMINI -> {
                val parts = j.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            }
        }
    }

    private suspend fun Call.await(): Pair<Int, String> = suspendCancellableCoroutine { c ->
        c.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!c.isCancelled) c.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { c.resume(it.code to it.body?.string().orEmpty()) }
            }
        })
    }
}
