package ir.beny.bot.data

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ApiException(val code: Int, val raw: String) : IOException(raw) {
    val friendly: String get() = when (code) {
        400 -> "درخواست نامعتبر است. نام مدل یا تنظیمات را بررسی کن."
        401 -> "کلید API اشتباه یا منقضی است."
        402 -> "موجودی حساب این سرویس کافی نیست."
        403 -> "دسترسی رد شد. کلید، پروژه یا منطقه‌ات اجازه‌ی استفاده ندارد."
        404 -> "مدل یا آدرس پیدا نشد. نام مدل را در تنظیمات اصلاح کن (دکمه‌ی دریافت لیست مدل‌ها)."
        429 -> "تعداد درخواست‌ها بیش از حد مجاز است. کمی صبر کن و دوباره امتحان کن."
        in 500..599 -> "سرور سرویس مشکل دارد. بعداً دوباره امتحان کن."
        else -> "خطای ناشناخته از سمت سرور."
    }
}

data class Cfg(
    val type: ProviderType,
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    val temperature: Double,
    val system: String,
    val needsKey: Boolean = true,
)

object ApiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    suspend fun send(cfg: Cfg, history: List<Msg>): String {
        require(!cfg.needsKey || cfg.apiKey.isNotBlank()) { "کلید API را در تنظیمات وارد کنید" }
        require(cfg.baseUrl.isNotBlank()) { "آدرس سرویس را در تنظیمات وارد کنید" }
        require(cfg.model.isNotBlank()) { "نام مدل را در تنظیمات وارد کنید" }
        val base = cfg.baseUrl.trimEnd('/')
        var (code, body) = http.newCall(build(cfg, base, history, true)).await()
        // بعضی مدل‌ها (مثل مدل‌های استدلالی) temperature را قبول نمی‌کنند؛ یک بار بدون آن تلاش می‌کنیم
        if (code == 400 && body.contains("temperature", ignoreCase = true)) {
            val r = http.newCall(build(cfg, base, history, false)).await()
            code = r.first; body = r.second
        }
        if (code !in 200..299) throw ApiException(code, extractMessage(body))
        return parse(cfg.type, body)
    }

    suspend fun listModels(cfg: Cfg): List<String> {
        require(cfg.baseUrl.isNotBlank()) { "آدرس سرویس را وارد کنید" }
        require(!cfg.needsKey || cfg.apiKey.isNotBlank()) { "اول کلید API را وارد کنید" }
        val base = cfg.baseUrl.trimEnd('/')
        val rb = Request.Builder().get()
        when (cfg.type) {
            ProviderType.OPENAI_COMPAT -> {
                rb.url("$base/models")
                if (cfg.apiKey.isNotBlank()) rb.addHeader("Authorization", "Bearer ${cfg.apiKey}")
            }
            ProviderType.ANTHROPIC -> rb.url("$base/models?limit=100")
                .addHeader("x-api-key", cfg.apiKey).addHeader("anthropic-version", "2023-06-01")
            ProviderType.GEMINI -> rb.url("$base/models?pageSize=200").addHeader("x-goog-api-key", cfg.apiKey)
        }
        val (code, body) = http.newCall(rb.build()).await()
        if (code !in 200..299) throw ApiException(code, extractMessage(body))
        val trimmed = body.trimStart()
        val ids = if (cfg.type == ProviderType.GEMINI) {
            val a = JSONObject(body).optJSONArray("models") ?: JSONArray()
            (0 until a.length()).map { a.getJSONObject(it) }.filter { m ->
                val methods = m.optJSONArray("supportedGenerationMethods")
                methods == null || (0 until methods.length()).any { methods.getString(it) == "generateContent" }
            }.map { it.getString("name").removePrefix("models/") }
        } else {
            val a = if (trimmed.startsWith("[")) JSONArray(body)
            else JSONObject(body).optJSONArray("data") ?: JSONArray()
            (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("id")?.takeIf { s -> s.isNotBlank() } }
        }
        return ids.distinct().sorted()
    }

    private fun build(c: Cfg, base: String, h: List<Msg>, withTemp: Boolean): Request = when (c.type) {
        ProviderType.OPENAI_COMPAT -> openAi(c, base, h, withTemp)
        ProviderType.ANTHROPIC -> anthropic(c, base, h, withTemp)
        ProviderType.GEMINI -> gemini(c, base, h, withTemp)
    }

    private fun extractMessage(body: String): String = runCatching {
        val j = JSONObject(body)
        when (val e = j.opt("error")) {
            is JSONObject -> e.optString("message", body)
            is String -> e
            else -> j.optString("message", body)
        }
    }.getOrDefault(body).take(400)

    private fun post(url: String, json: JSONObject, vararg headers: Pair<String, String>): Request =
        Request.Builder().url(url).post(json.toString().toRequestBody(JSON)).apply {
            headers.forEach { (k, v) -> addHeader(k, v) }
        }.build()

    private fun openAi(c: Cfg, base: String, h: List<Msg>, withTemp: Boolean): Request {
        val msgs = JSONArray()
        if (c.system.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", c.system))
        h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("messages", msgs)
        if (withTemp) body.put("temperature", c.temperature)
        val auth = if (c.apiKey.isNotBlank()) arrayOf("Authorization" to "Bearer ${c.apiKey}") else emptyArray()
        return post("$base/chat/completions", body, *auth)
    }

    private fun anthropic(c: Cfg, base: String, h: List<Msg>, withTemp: Boolean): Request {
        val msgs = JSONArray()
        h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", c.model).put("max_tokens", 4096).put("messages", msgs)
        if (withTemp) body.put("temperature", c.temperature.coerceAtMost(1.0))
        if (c.system.isNotBlank()) body.put("system", c.system)
        return post("$base/messages", body, "x-api-key" to c.apiKey, "anthropic-version" to "2023-06-01")
    }

    private fun gemini(c: Cfg, base: String, h: List<Msg>, withTemp: Boolean): Request {
        val contents = JSONArray()
        h.forEach {
            contents.put(
                JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.content)))
            )
        }
        val body = JSONObject().put("contents", contents)
        if (withTemp) body.put("generationConfig", JSONObject().put("temperature", c.temperature))
        if (c.system.isNotBlank())
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", c.system))))
        return post("$base/models/${c.model}:generateContent", body, "x-goog-api-key" to c.apiKey)
    }

    private fun parse(type: ProviderType, body: String): String {
        val j = JSONObject(body)
        return when (type) {
            ProviderType.OPENAI_COMPAT -> {
                val m = j.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                if (m.isNull("content")) "" else m.optString("content")
            }
            ProviderType.ANTHROPIC -> {
                val a = j.getJSONArray("content")
                (0 until a.length()).map { a.getJSONObject(it) }
                    .filter { it.optString("type") == "text" }.joinToString("") { it.optString("text") }
            }
            ProviderType.GEMINI -> {
                val parts = j.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            }
        }
    }

    private suspend fun Call.await(): Pair<Int, String> = suspendCancellableCoroutine { c ->
        c.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!c.isCancelled) c.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { c.resume(it.code to it.body?.string().orEmpty()) }
            }
        })
    }
}
