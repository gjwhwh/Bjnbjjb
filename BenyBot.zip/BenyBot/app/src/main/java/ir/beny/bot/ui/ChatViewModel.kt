package ir.beny.bot.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.beny.bot.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    val chats = mutableStateListOf<Chat>().apply { addAll(store.loadChats()) }
    var currentId by mutableStateOf<String?>(chats.firstOrNull()?.id)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var providerId by mutableStateOf(store.providerId)
    private var job: Job? = null

    val current: Chat? get() = chats.firstOrNull { it.id == currentId }
    val provider: Provider get() = Providers.byId(providerId)
    val modelName: String get() = store.model(providerId)

    fun cfg() = Cfg(
        provider.type, store.base(providerId), store.key(providerId),
        store.model(providerId), store.temperature.toDouble(), store.systemPrompt,
    )

    fun selectProvider(id: String) { providerId = id; store.providerId = id }

    fun newChat(): Chat {
        val c = Chat(UUID.randomUUID().toString(), "گفتگوی جدید")
        chats.add(0, c); currentId = c.id
        return c
    }

    fun open(id: String) { currentId = id; error = null }

    fun delete(id: String) {
        chats.removeAll { it.id == id }
        if (currentId == id) currentId = chats.firstOrNull()?.id
        persist()
    }

    fun clearAll() { chats.clear(); currentId = null; persist() }

    fun send(text: String) {
        if (text.isBlank() || loading) return
        val chat = current ?: newChat()
        chat.messages.add(Msg("user", text.trim()))
        if (chat.title == "گفتگوی جدید") chat.title = text.trim().take(30)
        generate(chat)
    }

    fun regenerate() {
        val chat = current ?: return
        if (loading) return
        if (chat.messages.lastOrNull()?.role == "assistant") chat.messages.removeAt(chat.messages.lastIndex)
        if (chat.messages.isNotEmpty()) generate(chat)
    }

    fun stop() { job?.cancel() }

    private fun generate(chat: Chat) {
        error = null; loading = true
        job = viewModelScope.launch {
            try {
                val reply = ApiClient.send(cfg(), chat.messages.toList())
                chat.messages.add(Msg("assistant", reply.ifBlank { "(پاسخ خالی)" }))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "خطای ناشناخته"
            } finally {
                loading = false; persist()
            }
        }
    }

    fun exportText(): String = current?.messages?.joinToString("\n\n") {
        (if (it.role == "user") "شما: " else "بنی‌بات: ") + it.content
    }.orEmpty()

    private fun persist() = store.saveChats(chats)
}
