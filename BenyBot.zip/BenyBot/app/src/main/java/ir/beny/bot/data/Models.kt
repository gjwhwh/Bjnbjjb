package ir.beny.bot.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList

enum class ProviderType { OPENAI_COMPAT, GEMINI, ANTHROPIC }

data class Provider(
    val id: String,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val models: List<String>,
    val needsKey: Boolean = true,
)

object Providers {
    private val O = ProviderType.OPENAI_COMPAT

    val all = listOf(
        Provider("openai", "OpenAI", O, "https://api.openai.com/v1", listOf("gpt-4o", "gpt-4o-mini")),
        Provider("anthropic", "Anthropic Claude", ProviderType.ANTHROPIC, "https://api.anthropic.com/v1",
            listOf("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-4-5-20251001")),
        Provider("gemini", "Google Gemini", ProviderType.GEMINI, "https://generativelanguage.googleapis.com/v1beta",
            listOf("gemini-3.8-flash", "gemini-2.5-flash-lite", "gemini-2.5-flash")),
        Provider("openrouter", "OpenRouter", O, "https://openrouter.ai/api/v1", listOf("openai/gpt-4o-mini")),
        Provider("deepseek", "DeepSeek", O, "https://api.deepseek.com/v1", listOf("deepseek-chat", "deepseek-reasoner")),
        Provider("groq", "Groq", O, "https://api.groq.com/openai/v1", listOf("llama-3.3-70b-versatile")),
        Provider("mistral", "Mistral", O, "https://api.mistral.ai/v1", listOf("mistral-small-latest", "mistral-large-latest")),
        Provider("xai", "xAI Grok", O, "https://api.x.ai/v1", listOf("grok-3-mini")),
        Provider("together", "Together AI", O, "https://api.together.xyz/v1", listOf("meta-llama/Llama-3.3-70B-Instruct-Turbo")),
        Provider("perplexity", "Perplexity", O, "https://api.perplexity.ai", listOf("sonar")),
        Provider("fireworks", "Fireworks", O, "https://api.fireworks.ai/inference/v1", listOf("accounts/fireworks/models/llama-v3p3-70b-instruct")),
        Provider("cerebras", "Cerebras", O, "https://api.cerebras.ai/v1", listOf("llama-3.3-70b")),
        Provider("sambanova", "SambaNova", O, "https://api.sambanova.ai/v1", listOf("Meta-Llama-3.3-70B-Instruct")),
        Provider("nvidia", "NVIDIA NIM", O, "https://integrate.api.nvidia.com/v1", listOf("meta/llama-3.3-70b-instruct")),
        Provider("huggingface", "Hugging Face", O, "https://router.huggingface.co/v1", listOf("meta-llama/Llama-3.3-70B-Instruct")),
        Provider("github", "GitHub Models", O, "https://models.github.ai/inference", listOf("openai/gpt-4o-mini")),
        Provider("moonshot", "Moonshot Kimi", O, "https://api.moonshot.ai/v1", listOf("moonshot-v1-8k")),
        Provider("qwen", "Alibaba Qwen", O, "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", listOf("qwen-plus")),
        Provider("zhipu", "Zhipu GLM", O, "https://open.bigmodel.cn/api/paas/v4", listOf("glm-4-flash")),
        Provider("siliconflow", "SiliconFlow", O, "https://api.siliconflow.com/v1", listOf("Qwen/Qwen2.5-7B-Instruct")),
        Provider("ollama", "Ollama (محلی)", O, "http://localhost:11434/v1", listOf("llama3.2"), needsKey = false),
        Provider("lmstudio", "LM Studio (محلی)", O, "http://localhost:1234/v1", emptyList(), needsKey = false),
        Provider("custom", "سفارشی (سازگار با OpenAI)", O, "", emptyList()),
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all.first()
}

data class Msg(val role: String, val content: String) // role: user | assistant

class Chat(val id: String, title: String, val messages: SnapshotStateList<Msg> = mutableStateListOf()) {
    var title by mutableStateOf(title)
}
