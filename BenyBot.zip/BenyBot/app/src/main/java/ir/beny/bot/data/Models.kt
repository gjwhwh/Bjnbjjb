package ir.beny.bot.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList

enum class ProviderType { OPENAI_COMPAT, GEMINI, ANTHROPIC }

data class Provider(
    val id: String,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val models: List<String>,
)

object Providers {
    val all = listOf(
        Provider("openai", "OpenAI", ProviderType.OPENAI_COMPAT, "https://api.openai.com/v1", listOf("gpt-4o", "gpt-4o-mini")),
        Provider("anthropic", "Anthropic Claude", ProviderType.ANTHROPIC, "https://api.anthropic.com/v1", listOf("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-4-5-20251001")),
        Provider("gemini", "Google Gemini", ProviderType.GEMINI, "https://generativelanguage.googleapis.com/v1beta", listOf("gemini-2.0-flash", "gemini-1.5-pro")),
        Provider("openrouter", "OpenRouter", ProviderType.OPENAI_COMPAT, "https://openrouter.ai/api/v1", listOf("openai/gpt-4o-mini", "google/gemini-flash-1.5")),
        Provider("deepseek", "DeepSeek", ProviderType.OPENAI_COMPAT, "https://api.deepseek.com/v1", listOf("deepseek-chat", "deepseek-reasoner")),
        Provider("groq", "Groq", ProviderType.OPENAI_COMPAT, "https://api.groq.com/openai/v1", listOf("llama-3.3-70b-versatile")),
        Provider("custom", "سفارشی (سازگار با OpenAI)", ProviderType.OPENAI_COMPAT, "", emptyList()),
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all.first()
}

data class Msg(val role: String, val content: String) // role: user | assistant

class Chat(val id: String, title: String, val messages: SnapshotStateList<Msg> = mutableStateListOf()) {
    var title by mutableStateOf(title)
}
